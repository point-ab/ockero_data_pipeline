# extract_and_transform/utils/utils.py
import os
from pathlib import Path

def find_project_root() -> Path:
    required_dirs = ["data", "data_in"]

    # 1️⃣ Explicit via .env (highest priority)
    env_root = os.getenv("PROJECT_ROOT")
    if env_root:
        root = Path(env_root).expanduser().resolve()
        missing = [d for d in required_dirs if not (root / d).exists()]
        if missing:
            raise RuntimeError(
                f"PROJECT_ROOT is set to {root} but missing required folders: {missing}"
            )
        return root

    # 2️⃣ Auto-detect by walking UP from cwd
    current = Path.cwd().resolve()

    for parent in [current] + list(current.parents):
        if all((parent / d).exists() for d in required_dirs):
            return parent

    # 3️⃣ Fail loudly
    raise RuntimeError(
        "Could not determine PROJECT_ROOT.\n"
        "Either:\n"
        " - set PROJECT_ROOT in .env, or\n"
        " - run the command from inside the project directory\n"
        "Expected folders: data/, data_in/"
    )