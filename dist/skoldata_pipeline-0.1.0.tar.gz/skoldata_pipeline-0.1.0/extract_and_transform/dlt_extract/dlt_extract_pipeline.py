from dlt_utils import *
from source_schoolsoft import *
from source_elin_testdata import *
from extract_and_transform.utils.utils import *
import extract_and_transform
import dlt
from dotenv import load_dotenv
from pathlib import Path

load_dotenv()


def get_duckdb_path():
    """
    Returns a path to the DuckDB file that works both in Git repo (dev) 
    and in installed package (client). Creates folder if needed.
    """
    # 1️⃣ Try to find 'data' folder next to package (dev or installed)
    package_root = Path(extract_and_transform.__file__).resolve().parent
    duckdb_candidate = package_root.parent / "data" / "db_pipeline.duckdb"

    if duckdb_candidate.parent.exists():
        # Use folder next to package
        duckdb_candidate.parent.mkdir(parents=True, exist_ok=True)
        return duckdb_candidate

    # 2️⃣ Fallback: create a local 'data/' folder in current working dir (client)
    local_data_folder = Path.cwd() / "data"
    local_data_folder.mkdir(parents=True, exist_ok=True)
    return local_data_folder / "db_pipeline.duckdb"


# Get final DuckDB path
duckdb_path1 = get_duckdb_path()

duckdb_path = project_root / "data" / "db_pipeline.duckdb"


 
# ### ------- Pipeline settings --------
    # pipeline_ss12000 = dlt.pipeline(
    #     pipeline_name="dlt-ss12000",
    #     destination=dlt.destinations.duckdb(duckdb_path), # absolut path, to sync with dbt project path!
    #     dataset_name="dlt_ss12000",
    #     progress="log", 
    # )   

    # Create a DLT pipeline
pipeline_schoolsoft = dlt.pipeline(
    pipeline_name="schoolsoft_pipeline",
    destination=dlt.destinations.duckdb(duckdb_path), # absolut path, to sync with dbt project path!
    dataset_name="dlt_schoolsoft"
)
    # Create a DLT pipeline
pipeline_elin_testdata = dlt.pipeline(
    pipeline_name="elin_testdata",
    destination=dlt.destinations.duckdb(duckdb_path), # absolut path, to sync with dbt project path!
    dataset_name="dlt_elin_testdata"
)
    
if __name__ == "__main__":

    from extract_and_transform.dlt_extract.dlt_utils import run_pipeline
    from extract_and_transform.dlt_extract.source_schoolsoft import schoolsoft_source
    from extract_and_transform.dlt_extract.source_elin_testdata import load_data_from_file

    #run_pipeline(pipeline_schoolsoft, schoolsoft_source())
    run_pipeline(pipeline_elin_testdata, load_data_from_file())


